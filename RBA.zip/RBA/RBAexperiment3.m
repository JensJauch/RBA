% This script performs an approximation of data points with B-spline
% functions whose coefficients are determined by recursive B-spline 
% approximation (RBA) as described in the subsections 3.6 and 3.7 of

% [1]: Jens Jauch, Felix Bleimund, Stephan Rhode, Frank Gauterin: 
%      Recursive B-Spline Approximation Using the Kalman Filter, 
%      Engineering Science and Technology, an International Journal (2016).
%      DOI: 10.1016/j.jestch.2016.09.015

%% Generate a set of data points (s_p,y_p_1), c.f. subsection 3.1 of [1]
s = 0.01:0.02:99.99; % Full data set
% s = 0.5:1:99.5; % Thinned out data set
% s = 99.5:-1:0.5; % Thinned out data set in reverse order
% s = [0.5:19.5,35.5:99.5]; % Thinned out data set with gap
% Thinned out data set in reverse order with gap
% s = [99.5:-1:35.5,19.5:-1:0.5];

y=[];
for p=1:size(s,2) 
    if (s(p)>=0 && s(p)<30)
        y = [y,10];
    elseif (s(p)>=30 && s(p)<70)
        y = [y,20];
    else
        y =[y,10];
    end
end

%% Parameters for B-spline function f(s)
d = 3; % degree of the B-spline function, d>=1
% Desired interval length (>0), i.e. distance between two neighboring
% knots. If the set of data points is chosen such that a shift operation by
% more than d+1 elements has to be performed, the knots of the knot vector 
% computed in fnc_calculate_2 will not be equidistant.
intLength = 5; 

%% Parameters for recursive B-spline approximation (RBA)
% ...Set are vectors whose i-th component is a parameter value that will be 
% used in the i-th run of RBA. 
% ISet is a vector that contains different numbers of spline intervals I.
ISet = [1,3,7,20];
% IStartSet is a vector that contains different values IStart which denote 
% the spline interval to which the first data point will belong. IStart=1 
%is the first spline interval and IStart=I the last spline interval.
% % IStart=1,2,...,I corresponds to mu = d+1,...,J with J=d+I in [1].
IStartSet = [1,1,1,1];
% xbarSet contains different initial values xbar for estimated spline 
% coefficients
xbarSet = [0,0,0,0];
% pbarSet contains different initial values pbar for the main diagonal of 
% the covariance matrix of a posteriori error P_plus
pbarSet = [1e4,1e4,1e4,1e4];
% qbarSet contains different values qbar for the main diagonal of the 
% covariance matrix of process noise Q
qbarSet = [1e-12,1e-12,1e-12,1e-12];
% Diagonal matrix with the reciprocals of the relative weights between the
% different target criterions for the approximating B-spline function f(s),
% on its diagonal, here [f close to data points (s_p,y_p_1), f' close to 
% zero, f'' close to zero]
R_RBA = diag([1e0,1e-2,1e-3]); 

%% Parameters for weighted least squares (WLS)
% Diagonal matrix with the reciprocals of the relative weights between the
% different target criterions for the approximating B-spline function f(s),
% on its diagonal, here [f close to data points (s_p,y_p_1), f' close to 
% zero, f'' close to zero]
R_WLS = diag([1e0,1e-2,1e-3]);

%% Parameters for plot function
% Horizontal distance between two neighboring positions where the
% B-splines functions are evaluated
resolution = 0.1; 
    
%% Perform calculations
[cRBAexp2,cWLSexp2,~,~,~,~] = fnc_calculate_2...
    (intLength,s,y,d,ISet,IStartSet,xbarSet,pbarSet,qbarSet,R_RBA,R_WLS);

IStartSet = [1,3,7,20];
[cRBA,cWLS,~,~,~,~] = fnc_calculate_2...
    (intLength,s,y,d,ISet,IStartSet,xbarSet,pbarSet,qbarSet,R_RBA,R_WLS);

%% Diplay results
fprintf('Difference of coefficient matrices:\n');
difference = cRBA-cRBAexp2

