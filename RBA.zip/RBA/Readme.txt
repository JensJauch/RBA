Run RBAexperiment1, RBAexperiment2 or RBAexperiment3 to perform an 
approximation of data points by B-spline functions whose coefficients are 
determined using the algorithm for recursive B-Spline approximation (RBA) 
in comparison with the solution determined by the weighted least squares 
(WLS) method as described in section 3 of

[1]: Jens Jauch, Felix Bleimund, Stephan Rhode, Frank Gauterin: 
     Recursive B-Spline Approximation Using the Kalman Filter, 
     Engineering Science and Technology, an International Journal (2016).
     DOI: 10.1016/j.jestch.2016.09.015

Some information about the attached MATLAB files and functions:

RBAexperiment1, RBAexperiment2 and RBAexperiment3 are script files in which
various parameters for the approximation can be changed, e.g.:
- The data points (s_p,y_p),p=1,2,...,P that are approximated by B-spline functions
- the desired distance intLength between two neighboring knots of the B-spline knot vector
- The degree d of the B-spline function
- The reciproclas of relative weights of different target criterions for the approximating function determined by RBA and WLS
  which are "f close to data points", "f' close to zero" and "f'' close to zero"
- The number of spline intervals I of the B-spline function 
The script files first invoke the function fnc_calculate_1.m and fnc_calculate_2.m, respectively, 
that perform the approximations and return the result. Second, they call fnc_plot_1.m and fnc_plot_2.m, respectively
that plots the data, the knot vector and the approximating functions. Finally, the calculation time for the different approaches
are printed to the console. The plotted data can be written to files. 
 
fnc_calculate_1.m (fnc_calculate_2.m) contains the following functions:
- fnc_calculate_1.m (fnc_calculate_2.m) performs an approximation using WLS followed by approximations using
	RBA with different parameter settings
- fnc_RBA performs a single iteration of RBA as described in Algorithm 2 of [1] and calls fnc_KF
- fnc_KF implements the Kalman filter as decribed in Algorithm 1 of [1]
- fnc_WLS implements the weighted least squares method and calls fnc_bMat
- fnc_bMat returns a matrix containing values of B-splines

fnc_BSpl.m returns a B-spline vector and is called by both fnc_calculate and fnc_plot

fnc_plot.m plots the data, the knot vector and the approximation functions determined by WLS and RBA

The files have been tested under both MATLAB R2012b 64bit and R2015b 64bit. 
Please let me know if you find bugs or need any help (jens.jauch@kit.edu).