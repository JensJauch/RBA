function [cRBA,cWLS,knotVecGlobal,tRBA,tWLS,printMessage] = fnc_calculate_2...
    (intLength,s,y,d,ISet,IStartSet,xbarSet,pbarSet,qbarSet,R_RBA,R_WLS)
% This function perfoms the approximation of data points (s_p,y_p) using
% the weighted least squares (WLS) method and the recursive B-Spline
% approximation (RBA) method as decribed in
%
% Jens Jauch, Felix Bleimund, Stephan Rhode, Frank Gauterin: 
% Recursive B-Spline Approximation Using the Kalman Filter, 
% Engineering Science and Technology, an International Journal (2016).
% DOI: 10.1016/j.jestch.2016.09.015
%
% For RBA, multiple approximations are performed with different settings 
% by the elements in the vectors ISet, IStartSet, xbarSet, pbarSet and
% qbarSet. pecifiedISet. For each approximation performed by WLS or RBA, 
% respectively, the function returns both the determined function 
% coefficients and knot vector as well as the required computation time.
% 
% cRBA:          Matrix of B-spline coefficients determined using RBA with 
% different parameter settings which vary along the columns
% cWLS:          B-spline coefficients determined using WLS
% knotVecGlobal: Knot vector of B-spline aproximation functions
% tRBA:      Vector that contains the computation time for each RBA run
% tWLS:      computation time required by WLS
% printMessage:  Boolean variable that indicates if the number of spline 
% intervals I has been limited for a run of RBA because I had been chosen 
% too large
% intLength:     Desired distance between two neighboring knots
% s:             Vector of supporting points s_p of data points (s_p,y_p)
% y:             Vector of values y_p of data points (s_p,y_p)
% d:             Degree of B-spline function
% ISet:          Vector that contains d
% IStartSet      Vector that contains different values IStart which denote 
% the spline interval to which the first data point will belong
% xbarSet:       Vector that contains different initial values xbar for 
% estimated spline coefficients
% pbarSet:       Vector that contains different initial values pbar for the 
% main diagonal of the covariance matrix of a posteriori error P_plus
% qbarSet:       Vector that contains different values qbar for the main 
% diagonal of the covariance matrix of process noise Q
% R_RBA:         Vector that contains the reciprocals of relative weights 
% between the different target criterions 
% R_WLS:         Vector that contains the reciprocals of relative weights 
% between the different target criterions 

%% Compute the global knot vector with equidistant knots if possible
% Sort the data and compute the distance between neigboring points
sSorted = sort(s);
ds = sSorted(2) - sSorted(1);
% Add 10 times the machine epsilon to the fraction intLength/ds before 
% rounding in order to avoid undesired results of the floor operation caused 
% by round-off-errors 
pointsPerInterval = floor(intLength/ds+10*eps(intLength/ds));
% Compute the necessary inner knots of the knot vector
innerKnots = sSorted(1)-ds/2:pointsPerInterval*ds:sSorted(end)+ds/2;
if (sSorted(end)>innerKnots(end))
    innerKnots = [innerKnots,innerKnots(end)+intLength];
end
% If the data points are not equidistant and there is a large gap between
% some neighboring data points, it might be necessary to adapt 
% the number and position of the knots in the global knot vector such that 
% appropriate additional knots are specified if fnc_RBA performs a shift 
% operation by more than d+1 elements. In case of a large gap, the
% following lines remove redundant knots and increase the distance of knots
% around a large gap of s_p in the data set. 

% Counter for the number of neighboring spline intervals without any data
% points
neighbIntervWithoutData = 0;
% Iterate through the inner knots
for i = 1:size(innerKnots,2)-1
    anyPointInInterval = false;
    % Iterate through the data set
    for p = 1:size(s,2)
        if(sSorted(p)>=innerKnots(i) && sSorted(p)<innerKnots(i+1))
            anyPointInInterval = true;
            % If there has been no data in more than d previous spline
            % intervals but there is data in the current spline interval,
            % the knots of the first d-1 empty spline intervals are adapted
            % using linear interpolation between the right border of the
            % last spline interval with data
            % (knots(i-neighbInterWithoutData)) and the left border of the 
            % current spline interval (knots(i))
            if(neighbIntervWithoutData>d)
                m = i-neighbIntervWithoutData+1:i-1;
                for n = 1:size(m,2);
                    if(n<=d-1)
                        % Adapt the position of the first d-1 knots
                        innerKnots(m(n)) = ...
                            innerKnots(i-neighbIntervWithoutData)+...
                            n*(innerKnots(i)-...
                            innerKnots(i-neighbIntervWithoutData))/d;
                    else
                        % Overwrite redundant knots with NaN to indicate 
                        % that they have to be removed
                        innerKnots(m(n)) = NaN;
                    end
                end
            end
            neighbIntervWithoutData = 0;
            break;
        end
    end
    if(~anyPointInInterval)
        neighbIntervWithoutData = neighbIntervWithoutData+1;
    end
end
% Remove redundant knots
innerKnots = innerKnots(~isnan(innerKnots));
% Compute additional knots for the beginning and end of the global knot
% vector
knotsBeg = innerKnots(1)-d*intLength:intLength:innerKnots(1)-intLength;
knotsEnd = innerKnots(end)+intLength:intLength:innerKnots(end)+d*intLength;
% Compose the global knot vector whose elements are used to initialize the
% knot vector for fnc_RBA and to provide additional knots in case of shift
% shift operations
knotVecGlobal = [knotsBeg,innerKnots,knotsEnd];

%% Define the global knot vector manually
% In experiment 1, a knot vector with not equidistant knots is used
% knotVecGlobal=[-10,-6.6,-3,-1,25,35,60,80,100,101,103.2,110];

%% Perform approximation using weighted least squares (WLS)
tic;
% Coefficients of B-spline function determined by WLS
cWLS = fnc_WLS(s,y,knotVecGlobal,d,R_WLS);
tWLS = toc; % Computation time required by WLS

%% Perform approximation using recursive B-Spline approximation (RBA)
% Intialize matrix cRBA. Each column contain the coefficients of the 
% B-spline function determined by RBA. The parameter settings of RBA vary 
% along the rows of cRBA
cRBA = NaN*ones(size(knotVecGlobal,2)-d-1,size(ISet,2)); 
% Vector that stores the computation time required by RBA with different 
% settings
tRBA = zeros(1,size(ISet,2)); 
% Print a message that the number of spline intervals I has been limited
% for a run of RBA because I had been chosen too large
printMessage = false;
% Iteration through all different components of ISet
for i=1:size(ISet,2)
    % Determine the number of spline intervals I and the spline interval 
    % IStart to which the first data points will belong. 
    I = ISet(i);
    if(I>size(knotVecGlobal,2)-2*d-1)
        printMessage = true;
        I = size(knotVecGlobal,2)-2*d-1;
    end
    IStart = min(IStartSet(i),I);
    
    %% Initialize the knot vector knotVecRBA that is used by RBA and 
    % contains only knots for I intervals.
    J = d+I; % Total number of B-splines
    K = d+J+1; % Total number of knots
    knotVecRBA = NaN*ones(1,K);
    % Spline interval of first data point
    mu_s1 = find(knotVecGlobal<=s(1),1,'last');
    leftPart = max(1,mu_s1-d-IStart+1):mu_s1;
    rightPart = mu_s1+1:min(mu_s1-d-IStart+K,size(knotVecGlobal,2));
    knotVecRBA([max(1,(-(size(leftPart,2)-1)+d+IStart)):d+IStart,...
        d+IStart+1:min(d+IStart+1+size(rightPart,2)-1,K)]) ...
        = knotVecGlobal([leftPart,rightPart]);
    % Initialize the a posteriori state estimation (estimated B-spline 
    % coefficients)
    xVecHatPlus = xbarSet(i)*ones(J,1); 
    % Initialize the covariance matrix of a posteriori estimation error
    P_plus = pbarSet(i)*eye(d+I); 
    % Row of cRBA where xVecHatPlus(1) will be stored at the end of the
    % approximation
    positionxVecHatPlus = 1;
    % Start time measurement
    tic;
    %% Iterate through all data points
    for p=1:size(s,2)
        % KnotVecbar contains the knots that are needed by fnc_RBA in case
        % of a shift operation        
        knotVecbar = NaN*ones(1,size(knotVecRBA,2));
        if(s(p)>=knotVecRBA(J+1))
            % A right shift will be performed by fnc_RBA. Determine the 
            % shift variable sigma and copy the knots that will be needed 
            % by fnc_RBA for shift operation from the knotVecGlobal to 
            % knotVecbar
            if(s(p)>=knotVecRBA(K))
                sigma = d+1;
                knotVecbar(K-sigma+1:K) = knotVecGlobal(find(...
                    knotVecGlobal>s(p),sigma,'first'));
            else
                sigma=find(knotVecRBA<=s(p),1,'last')-J;
                knotVecbar(K-sigma+1:K) = knotVecGlobal(find(...
                    knotVecGlobal>knotVecRBA(end),sigma,'first'));
            end
            % Copy coefficient estimates in xHatVecPlus that will be
            % overwritten during the shift operation to cRBA
            muglobal = find(knotVecGlobal<=s(p),1,'last');
            cVec = max(1,muglobal-I-sigma-d+1):muglobal-I-1-d+1;
            if(size(cVec,2)>0)
                cRBA(cVec,i) = xVecHatPlus(sigma-size(cVec,2)+1:sigma);
            end
            % Update the row of cRBA where xVecHatPlus(1) will be stored at 
            % the end of the approximation
            positionxVecHatPlus = max(1,min(size(cRBA,1)-(J-1),muglobal-I));
        elseif(s(p)<knotVecRBA(d+1))
            % A left shift will be performed by fnc_RBA. Determine the 
            % shift variable sigma and copy the knots that will be needed 
            % by fnc_RBA for shift operation from the knotVecGlobal to 
            % knotVecbar
            if(s(p)<knotVecRBA(1))
                sigma = -(d+1);
                knotVecbar(1:-sigma) = ...
                    knotVecGlobal(find(knotVecGlobal<=s(p),-sigma,'last'));
            else
                sigma=find(knotVecRBA<=s(p),1,'last')-(d+1);
                knotVecbar(1:-sigma) = knotVecGlobal(...
                    find(knotVecGlobal<knotVecRBA(1),-sigma,'last'));
            end
            % Copy coefficient estimates in xHatVecPlus that will be
            % overwritten during the next shift operation to cRBA
            muglobal = find(knotVecGlobal<=s(p),1,'last');
            cVec = muglobal+J-d:min(muglobal+I-1-sigma,size(cRBA,1));
            if(size(cVec,2)>0)
                cRBA(cVec,i) = xVecHatPlus(J+sigma+1:J);
            end
            % Update the row of cRBA where xVecHatPlus(1) will be stored at 
            % the end of the approximation
            positionxVecHatPlus = max(1,min(muglobal-d,size(cRBA,1)-J+1));
        end
        % Perform one RBA iteration
        [xVecHatPlus,P_plus,knotVecRBA] = fnc_RBA(knotVecRBA,xVecHatPlus,P_plus,R_RBA,s(p),[y(p);0;0],knotVecbar,xbarSet(i),pbarSet(i),qbarSet(i));
    end
    % Copy all elements of xVecHatPlus to cRBA
    cRBA(positionxVecHatPlus+[0:J-1],i) = xVecHatPlus;
    % Save the required computation time of the RBA run
    tRBA(i) = toc;
end
end

function [xHatVecPlus,P_plus,knotVec] = fnc_RBA...
    (knotVecOld,xVecHatPlusOld,P_plusOld,R,s,y,knotVecbar,xbar,pbar,qbar)
% This function implements the algorithm for recursive B-Spline 
% approximation (RBA) proposed in
%
% Jens Jauch, Felix Bleimund, Stephan Rhode, Frank Gauterin: 
% Recursive B-Spline Approximation Using the Kalman Filter, 
% Engineering Science and Technology, an International Journal (2016).
% DOI: 10.1016/j.jestch.2016.09.015
%
% xHatVecPlus:    A posteriori state estimate of current iteration
% P_plus:         Covariance matrix of a posteriori estimation error of
% current iteration
% knotVec:        Knot vector of current iteration
% knotVecOld:     Knot vector of previous iteration
% xVecHatPlusOld: A posteriori state estimate of previous iteration
% P_plusOld:      Covariance matrix of a posteriori estimation error of
% previous iteration
% R:              Diagonal matrix with the reciprocals of the relative 
% weights between the different target criterions for the approximating 
% B-spline function
% s:              Supporting point s_p of data point (s_p,y_p)
% y:              Value y_p of data point (s_p,y_p)
% knotVecbar:     Knot vector that contains additional knots needed for a
% shift operation 
% xbar:           Initial estimate for spline coefficients
% pbar:           Initial value for elements on the main diagonal of 
% the covariance matrix of a posteriori error P_plus
% qbar:           Value for elements on the main diagonal of the 
% covariance matrix of process noise Q

J = size(xVecHatPlusOld,1); % Number of B-splines
K = size(knotVecOld,2); % Number of knots
d = K-J-1; % Degree of the B-spline function
% Computation of sigma
sigma = 0;
if(s>=knotVecOld(J+1))
    if(s>=knotVecOld(K))
        sigma = d+1;
    else
        sigma = find(knotVecOld<=s,1,'last')-J;
    end
elseif(s<knotVecOld(d+1))
    if(s<knotVecOld(1))
        sigma = -(d+1);
    else
        sigma = find(knotVecOld<=s,1,'last')-(d+1);
    end
end
% Computation of calA
calA = zeros(J,J);
for i=1:J
    for j=1:J
        if(j==i+sigma)
            calA(i,j) = 1;
        end
    end
end
% Initialize the covariance matrix of process noise
Q = qbar*eye(J,J);
if(sigma>=0) % Right shift of the definition range of the B-spline function
    knotVec = [knotVecOld(sigma+1:K),knotVecbar(K-sigma+1:K)];
    u = [zeros(J-sigma,1);xbar*ones(sigma,1)];
    for i=J-sigma+1:J
        Q(i,i) = pbar;
    end
else % Left shift of the definition range of the B-spline function
    knotVec = [knotVecbar(1:-sigma),knotVecOld(1:K+sigma)];
    u = [xbar*ones(-sigma,1);zeros(J+sigma,1)];
    for i=1:-sigma
        Q(i,i) = pbar;
    end
end
% Compute the index mu of the spline interval to which s belongs
mu = find(knotVec<=s,1,'last');
% Compute the measurment matrix
calC = [zeros(3,mu-d-1),[fnc_BSpl(knotVec,mu,s,d,0);...
    fnc_BSpl(knotVec,mu,s,d,1);fnc_BSpl(knotVec,mu,s,d,2)],zeros(3,J-mu)]; 
% Perfom a Kalman filter iteration
[xHatVecPlus, P_plus] = fnc_KF...
    (xVecHatPlusOld,P_plusOld, u, y, calA, eye(J), calC, Q, R);
end


function [xHatVecPlus, P_plus]  =  fnc_KF...
    (xHatVecPlusOld, P_plusOld, u, y, A, B, C, Q, R)
% This function implements a standard Kalman filter as described in
% D. Simon, Optimal State Estimation: Kalman, H Infinity, and Nonlinear 
% Approaches, Wiley, 2006
% and 
%
% Jens Jauch, Felix Bleimund, Stephan Rhode, Frank Gauterin: 
% Recursive B-Spline Approximation Using the Kalman Filter, 
% Engineering Science and Technology, an International Journal (2016).
% DOI: 10.1016/j.jestch.2016.09.015
% 
% xVecHatPlus:    A posteriori state estimate of current iteration
% P_plus:         Covariance matrix of a posteriori estimation error of
% current iteration
% xVecHatPlusOld: A posteriori state estimate of previous iteration
% P_plusOld:      Covariance matrix of a posteriori estimation error of 
% previous iteration
% u:             Input
% y:             Measurement
% A:             State transition matrix
% B:             Input matrix
% C:             Measurement transition matrix
% R:             Covariance matrix of measurement noise
% Q:             Covariance matrix of process noise

% Time update
P_minus = A * P_plusOld * A' + Q; % Covariance of a priori estimation error
xHatMinus = A * xHatVecPlusOld + B * u; % A priori state estimate

% Measurement update      
K = (P_minus * C') / (C * P_minus * C' + R); % Obtain Kalman gain

% Covariance of a posteriori estimation error:
% - Joseph stabilized version, guarantees that P_plus is symmetric 
% positive definite as long as P_minus is symmetric positive:
P_plus = (eye(size(K,1)) - K * C) * P_minus *(eye(size(K,1)) - K * C)'...
    + K * R * K'; 
% - Simpler computation but no guarantee for symmetry or positive 
% definiteness:
%     P_plus = P_minus - K * C * P_minus; 
e = y - (C * xHatMinus); % Estimation error
xHatVecPlus = xHatMinus + K * e; % A posteriori state estimate         
end

function cWLS = fnc_WLS (s,y,k,d,R)
% This function implements the weighted least squares method as described in
% D. Simon, Optimal State Estimation: Kalman, H Infinity, and Nonlinear 
% Approaches, Wiley, 2006.
% It returns the determined vector of B-spline coefficients. The 
% approximation function is a B-spline function of degree d.
%
% cWLS: B-spline coefficients determined using WLS
% s:    Vector of supporting points s_p of data points (s_p,y_p)
% y:    Vector of values y_p of data points (s_p,y_p)
% k:    Knot vector of B-spline function
% d:    Degree of B-spline function
% R:    Diagonal matrix with reciprocals of relative weights between the 
% different target criterions

% Compute the measurement matrix
C = [fnc_bMat(s, k,d,0);fnc_bMat(s, k,d,1);fnc_bMat(s, k,d,2)];
% Compute the vector yy that contains P y values followed by 2P zeros as y 
% values for the first and second derivative of the B-spline function
yy = [];
for i = 1:size(C,1)
    if(i <=1/3*size(C,1))
        yy(i,1) = [y(i)];
    elseif (i>1/3*size(C,1) && i<=2/3*size(C,1))
        yy(i,1) = 0;
    else
        yy(i,1) = 0;
    end
end
% Compute the matrix RR that contains the reciprocals of the weights on its
% diagonal. The y values of the data points, and the zeros in yy for the 
% first and second derivative of the B-spline function can be weighted
% unequally
RR = zeros(size(C,1));
for i = 1:size(C,1)
    if(i<=size(C,1)/3)
        RR(i,i) = R(1,1);
    elseif (i>size(C,1)/3 && i<= 2/3*size(C,1))
        RR(i,i) = R(2,2);
    else
        RR(i,i) = R(3,3);
    end
end
CT = C';
cWLS = CT*(RR\C)\CT*(RR\yy); % Determine the B-spline coefficients
end

function bMat = fnc_bMat(s,k,d,r)
% This function returns the design matrix for the r-th derivative of a 
% B-spline function of degree d with knot vector k that is needed by 
% function fnc_WLS
%
% bMat: B-spline design matrix that contains the vector of B-splines for 
% s_p in row p, possibly preceeded and followed by zeros
% s:    Vector of supporting points s_p of data points (s_p,y_p)
% k:    Knot vector of B-spline function
% d:    Degree of B-spline function
% r:    Order of derivative of B-spline function

% Compute the design matrix for the B-spline function including its first 
% two derivatives
bMat = zeros(size(s,2),size(k,2)-d-1);
for p=1:size(s,2)
    % Determine index mu of the spline interval to which s_p belongs
    mu = find(k<=s(p),1,'last');
    bMat(p,mu-d:mu) = fnc_BSpl(k,mu,s(p),d,r); % Insert B-spline vector
end
end